//
//  schlijperAppDelegate.h
//  schlijper
//
//  Created by rabshakeh on 10/1/09 - 1:20 PM.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <Three20/Three20.h>

@interface schlijperAppDelegate : NSObject <UIApplicationDelegate> 

@end

